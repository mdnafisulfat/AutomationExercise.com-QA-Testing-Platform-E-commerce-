from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Step 1 & 2: Launch browser and navigate to site
driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://automationexercise.com")
time.sleep(2)

# Step 3: Click 'Signup / Login'
driver.find_element(By.XPATH, "//a[contains(text(),'Signup / Login')]").click()
time.sleep(2)

# Step 4: Enter name and email
driver.find_element(By.NAME, "name").send_keys("Nafis Test")
driver.find_element(By.XPATH, "//input[@data-qa='signup-email']").send_keys("nafisulftest1234@example.com")
time.sleep(1)

# Step 5: Click 'Signup' button
driver.find_element(By.XPATH, "//button[contains(text(),'Signup')]").click()
time.sleep(2)

# Step 6: Fill account info
driver.find_element(By.ID, "id_gender1").click()
driver.find_element(By.ID, "password").send_keys("Test1234")

# Date of Birth
driver.find_element(By.ID, "days").send_keys("10")
driver.find_element(By.ID, "months").send_keys("May")
driver.find_element(By.ID, "years").send_keys("1995")

# Address Info
driver.find_element(By.ID, "first_name").send_keys("Nafis")
driver.find_element(By.ID, "last_name").send_keys("Ulfat")
driver.find_element(By.ID, "address1").send_keys("123 Test Road")
driver.find_element(By.ID, "state").send_keys("Dhaka")
driver.find_element(By.ID, "city").send_keys("Dhaka")
driver.find_element(By.ID, "zipcode").send_keys("1212")
driver.find_element(By.ID, "mobile_number").send_keys("01700000000")

# Step 7: Click 'Create Account'
driver.find_element(By.XPATH, "//button[contains(text(),'Create Account')]").click()
time.sleep(3)

# Step 8: Verify 'ACCOUNT CREATED!'
if "ACCOUNT CREATED!" in driver.page_source:
    print("✅ Test Passed: Account successfully created.")
else:
    print("❌ Test Failed: Account creation message not found.")

time.sleep(2)
driver.quit()
