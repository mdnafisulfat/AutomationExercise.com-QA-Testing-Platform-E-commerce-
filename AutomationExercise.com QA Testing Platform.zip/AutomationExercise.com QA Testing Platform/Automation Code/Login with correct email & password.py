from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Step 1 & 2: Launch browser and navigate to site
driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://automationexercise.com")
time.sleep(2)

# Step 3: Click 'Signup / Login'
driver.find_element(By.XPATH, "//a[contains(text(),'Signup / Login')]").click()
time.sleep(2)

# Step 4: Enter valid email and password
driver.find_element(By.XPATH, "//input[@data-qa='login-email']").send_keys("nafisulftest1234@example.com")
driver.find_element(By.XPATH, "//input[@data-qa='login-password']").send_keys("Test1234")

# Step 5: Click Login
driver.find_element(By.XPATH, "//button[contains(text(),'Login')]").click()
time.sleep(3)

# ✅ Step 6: Verify user is logged in
if "Logged in as" in driver.page_source:
    print("✅ Test Passed: User successfully logged in.")
else:
    print("❌ Test Failed: Login message not found.")

time.sleep(2)
driver.quit()
