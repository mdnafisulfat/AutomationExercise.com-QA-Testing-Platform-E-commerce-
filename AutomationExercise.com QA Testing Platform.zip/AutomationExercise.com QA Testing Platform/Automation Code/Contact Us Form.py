from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import os

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://automationexercise.com")
time.sleep(2)

# Step 1: Click 'Contact Us'
driver.find_element(By.XPATH, "//a[contains(text(),'Contact us')]").click()
time.sleep(2)

# Step 2: Fill name, email, subject, message
driver.find_element(By.NAME, "name").send_keys("Nafis Ulfat")
driver.find_element(By.NAME, "email").send_keys("nafisulftest1234@example.com")
driver.find_element(By.NAME, "subject").send_keys("Test Subject")
driver.find_element(By.ID, "message").send_keys("This is a test message for Contact Us form.")

# Step 3: Upload file (make sure test file exists)
file_path = os.path.abspath("testfile.txt")
driver.find_element(By.NAME, "upload_file").send_keys(file_path)
time.sleep(1)

# Step 4: Click Submit
driver.find_element(By.NAME, "submit").click()
time.sleep(2)

# ✅ Handle the alert that appears
try:
    alert = driver.switch_to.alert
    alert.accept()
    print("🟡 Alert accepted.")
except:
    print("⚠️ No alert appeared.")

time.sleep(3)

# Step 5: Verify success message
if "Success! Your details have been submitted successfully." in driver.page_source:
    print("✅ Test Passed: Contact form submitted successfully.")
else:
    print("❌ Test Failed: Success message not found.")

time.sleep(2)
driver.quit()
