from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://automationexercise.com")
time.sleep(3)

# Step 1: Scroll to footer subscription section
footer = driver.find_element(By.ID, "footer")
actions = ActionChains(driver)
actions.move_to_element(footer).perform()
time.sleep(2)

# Step 2: Enter email in subscription input
driver.find_element(By.ID, "susbscribe_email").send_keys("nafisulftest1234@example.com")
time.sleep(1)

# Step 3: Click Subscribe button
driver.find_element(By.ID, "subscribe").click()
time.sleep(3)

# Verify success message
if "You have been successfully subscribed!" in driver.page_source:
    print("✅ Test Passed: Subscription success message displayed.")
else:
    print("❌ Test Failed: Subscription success message NOT found.")

time.sleep(2)
driver.quit()
