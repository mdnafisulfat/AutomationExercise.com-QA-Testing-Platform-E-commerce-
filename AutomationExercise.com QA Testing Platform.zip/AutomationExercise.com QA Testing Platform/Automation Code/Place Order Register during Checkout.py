from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Setup
driver = webdriver.Chrome()
driver.maximize_window()
wait = WebDriverWait(driver, 10)

try:
    # Step 1: Go to site
    driver.get("https://automationexercise.com")
    print("🟢 Opened automationexercise.com")

    # Step 2: Click 'Products'
    print("🟢 Clicking on 'Products'")
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(text(),'Products')]"))).click()
    time.sleep(2)

    # Step 3: Add first product to cart
    print("🟢 Clicking 'Add to Cart' on first product")
    add_button = wait.until(EC.element_to_be_clickable((By.XPATH, "(//a[contains(text(),'Add to cart')])[1]")))
    driver.execute_script("arguments[0].click();", add_button)
    time.sleep(2)

    print("🟢 Clicking 'Continue Shopping'")
    wait.until(EC.element_to_be_clickable((By.XPATH, "//button[contains(text(),'Continue Shopping')]"))).click()
    time.sleep(2)

    # Step 4: Click Cart
    print("🟢 Clicking on 'Cart'")
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(text(),'Cart')]"))).click()
    time.sleep(2)

    # Step 5: Proceed to Checkout
    print("🟢 Proceeding to Checkout")
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(text(),'Proceed To Checkout')]"))).click()
    time.sleep(2)

    # Step 6: Click Register/Login
    print("🟢 Navigating to Register/Login")
    wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(text(),'Register / Login')]"))).click()

    # Step 7: Fill registration form
    print("🟢 Filling registration form")
    wait.until(EC.visibility_of_element_located((By.NAME, "name")))
    wait.until(EC.visibility_of_element_located((By.XPATH, "//input[@data-qa='signup-email']")))
    driver.find_element(By.NAME, "name").send_keys("Nafis New")
    driver.find_element(By.XPATH, "//input[@data-qa='signup-email']").send_keys("nafisnew12345@example.com")
    driver.find_element(By.XPATH, "//button[contains(text(),'Signup')]").click()
    time.sleep(2)

    # Step 8: Fill account info
    print("🟢 Filling account information")
    wait.until(EC.element_to_be_clickable((By.ID, "id_gender1"))).click()
    driver.find_element(By.ID, "password").send_keys("Test12345")
    driver.find_element(By.ID, "days").send_keys("15")
    driver.find_element(By.ID, "months").send_keys("June")
    driver.find_element(By.ID, "years").send_keys("1990")
    driver.find_element(By.ID, "first_name").send_keys("Nafis")
    driver.find_element(By.ID, "last_name").send_keys("Ulfat")
    driver.find_element(By.ID, "address1").send_keys("123 New Road")
    driver.find_element(By.ID, "state").send_keys("Dhaka")
    driver.find_element(By.ID, "city").send_keys("Dhaka")
    driver.find_element(By.ID, "zipcode").send_keys("1215")
    driver.find_element(By.ID, "mobile_number").send_keys("01700000001")
    driver.find_element(By.XPATH, "//button[contains(text(),'Create Account')]").click()
    time.sleep(2)

    # Step 9: Continue
    print("🟢 Clicking Continue after account creation")
    wait.until(EC.element_to_be_clickable((By.LINK_TEXT, "Continue"))).click()
    time.sleep(2)

    # Step 10: Place order
    print("🟢 Placing the order")
    wait.until(EC.presence_of_element_located((By.NAME, "name_on_card"))).send_keys("Nafis Ulfat")
    driver.find_element(By.NAME, "card_number").send_keys("4111111111111111")
    driver.find_element(By.NAME, "cvc").send_keys("123")
    driver.find_element(By.NAME, "expiry_month").send_keys("12")
    driver.find_element(By.NAME, "expiry_year").send_keys("2025")
    driver.find_element(By.ID, "submit").click()
    time.sleep(2)

    # Step 11: Verify confirmation message
    if "Your order has been placed successfully!" in driver.page_source:
        print("✅ Test Passed: Order placed successfully.")
    else:
        print("❌ Test Failed: Order confirmation message not found.")

except Exception as e:
    driver.save_screenshot("PlaceOrder_Error.png")
    print("❌ Test Failed: An unexpected error occurred.")
    print("Error:", repr(e))

finally:
    time.sleep(2)
    driver.quit()
