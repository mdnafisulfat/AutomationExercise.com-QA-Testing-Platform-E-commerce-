from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://automationexercise.com")
print("Opened automationexercise.com")
time.sleep(2)

# Step 1: Click 'Products'
print("Clicking on 'Products'")
driver.find_element(By.XPATH, "//a[contains(text(),'Products')]").click()
time.sleep(3)

# Step 2: Add first product to cart
print("Adding first product to cart")
first_product = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.XPATH, "(//a[contains(text(),'Add to cart')])[1]"))
)
driver.execute_script("arguments[0].scrollIntoView(true);", first_product)
time.sleep(1)
first_product.click()
time.sleep(2)

# Step 3: Click 'Continue Shopping'
print("Clicking 'Continue Shopping'")
driver.find_element(By.XPATH, "//button[contains(text(),'Continue Shopping')]").click()
time.sleep(2)

# Step 4: Add second product to cart
print("Adding second product to cart")
second_product = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.XPATH, "(//a[contains(text(),'Add to cart')])[2]"))
)
driver.execute_script("arguments[0].scrollIntoView(true);", second_product)
time.sleep(1)

try:
    second_product.click()
except Exception as e:
    print("Could not click on second product directly. Trying JS click.")
    driver.execute_script("arguments[0].click();", second_product)

time.sleep(2)

# Step 5: Click 'Continue Shopping'
driver.find_element(By.XPATH, "//button[contains(text(),'Continue Shopping')]").click()
time.sleep(2)

# Step 6: Go to Cart
print("Navigating to cart")
driver.find_element(By.XPATH, "//a[contains(text(),'Cart')]").click()
time.sleep(3)

# Step 7: Click remove (X) icon beside first item
print("Attempting to remove product")
remove_buttons = driver.find_elements(By.XPATH, "//a[@class='cart_quantity_delete']")
if remove_buttons:
    remove_buttons[0].click()
    time.sleep(3)
else:
    print("No remove buttons found!")

# Step 8: Verify item removed
products = driver.find_elements(By.XPATH, "//tr[contains(@id, 'product-')]")
if len(products) < 2:
    print("Test Passed: Product removed from cart successfully.")
else:
    print("Test Failed: Product still present in cart.")

time.sleep(2)
driver.quit()
