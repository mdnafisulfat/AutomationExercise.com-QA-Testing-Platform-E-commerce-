from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
import time

# ✅ Chrome options to prevent timeout and ad/rendering issues
options = Options()
options.add_argument("--disable-extensions")
options.add_argument("--disable-gpu")
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--remote-debugging-port=9222")
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option('useAutomationExtension', False)

# ✅ Launch Chrome
driver = webdriver.Chrome(options=options)
driver.maximize_window()
driver.get("https://automationexercise.com")
time.sleep(2)

# Step 1: Click 'Products'
driver.find_element(By.XPATH, "//a[contains(text(),'Products')]").click()
time.sleep(3)

# Continue with rest of the test (e.g., hover & add to cart)...

driver.quit()
