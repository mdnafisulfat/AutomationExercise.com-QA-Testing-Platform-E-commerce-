from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://automationexercise.com")
time.sleep(2)

# Step 1: Click 'Products'
driver.find_element(By.XPATH, "//a[contains(text(),'Products')]").click()
time.sleep(3)

# Step 2: Click 'View Product' using JS to avoid ads blocking
try:
    view_product = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "(//a[contains(text(),'View Product')])[1]"))
    )
    driver.execute_script("arguments[0].scrollIntoView(true);", view_product)
    time.sleep(1)
    driver.execute_script("arguments[0].click();", view_product)
    print("🟢 Clicked on 'View Product'")
except:
    print("❌ Could not click on 'View Product'.")
    driver.quit()
    exit()

# Step 3: Get product info block and print all text
try:
    product_info = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.CLASS_NAME, "product-information"))
    )

    info_text = product_info.text  # get all text together
    print("✅ Test Passed: Product details found.")
    print("📦 Product Information:\n", info_text)

except Exception as e:
    print("❌ Test Failed: Could not find product details.")
    print("Error:", e)

time.sleep(2)
driver.quit()
