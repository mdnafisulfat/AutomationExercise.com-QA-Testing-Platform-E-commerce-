from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Step 1 & 2: Launch browser and go to login page
driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://automationexercise.com")
time.sleep(2)

driver.find_element(By.XPATH, "//a[contains(text(),'Signup / Login')]").click()
time.sleep(2)

# Step 3: Enter wrong email and password
driver.find_element(By.XPATH, "//input[@data-qa='login-email']").send_keys("wrongemail@example.com")
driver.find_element(By.XPATH, "//input[@data-qa='login-password']").send_keys("wrongpassword")
time.sleep(1)

# Step 4: Click Login
driver.find_element(By.XPATH, "//button[contains(text(),'Login')]").click()
time.sleep(3)

# Verify error message is visible
if "Your email or password is incorrect!" in driver.page_source:
    print("✅ Test Passed: Correct error message displayed.")
else:
    print("❌ Test Failed: Error message not found.")

time.sleep(2)
driver.quit()
