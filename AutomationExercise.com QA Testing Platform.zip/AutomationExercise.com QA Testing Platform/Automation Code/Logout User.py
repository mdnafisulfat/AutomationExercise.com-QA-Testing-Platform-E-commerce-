from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Step 1: Launch browser and login
driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://automationexercise.com")
time.sleep(2)

driver.find_element(By.XPATH, "//a[contains(text(),'Signup / Login')]").click()
time.sleep(2)

driver.find_element(By.XPATH, "//input[@data-qa='login-email']").send_keys("nafisulftest1234@example.com")
driver.find_element(By.XPATH, "//input[@data-qa='login-password']").send_keys("Test1234")
driver.find_element(By.XPATH, "//button[contains(text(),'Login')]").click()
time.sleep(3)

# Step 2: Click Logout
driver.find_element(By.XPATH, "//a[contains(text(),'Logout')]").click()
time.sleep(3)

# Step 3: Verify redirection to login page by checking URL or page content
current_url = driver.current_url
if "login" in current_url.lower():
    print("✅ Test Passed: User is redirected to login page after logout.")
else:
    print("❌ Test Failed: User not redirected to login page.")

time.sleep(2)
driver.quit()
